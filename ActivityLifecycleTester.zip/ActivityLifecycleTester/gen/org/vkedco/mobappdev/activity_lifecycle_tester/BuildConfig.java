/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.mobappdev.activity_lifecycle_tester;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}